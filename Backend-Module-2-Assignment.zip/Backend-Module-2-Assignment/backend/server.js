const express = require("express");
const app = express();
const PORT = 4000;
const cors = require("cors")
const storage = require("node-persist");
const { key, value } = require("node-persist")

//Storage Initialisation//
storage.init()

app.use(express.json());
app.use(cors());

//POST request to store the data//
app.post("/addTodo", async (req, res) => {
    const { todo } = req.body;
    const id = Date.now().toString();
    await storage.setItem(id, { id: id, todo: todo });
    res.status(200).json("TODO Added Successfully");

});
//Get request to get data //
app.get("/getTodo", async (req, res) => {
    todos = await storage.values()
    res.status(200).json({ data: todos });
});

//delete request to clear storage when browser get refreshed//
app.delete("/getTodo", async (req, res) => {
    todos = await storage.clear()
    res.status(200).json({ data: todos });
});

//Port 4000//
app.listen(PORT, () => {
    console.log("To Do App Started on Port", PORT)
});